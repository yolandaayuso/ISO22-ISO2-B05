import static org.junit.Assert.*;

import org.junit.Test;

public class iteracion5PeregrinosTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

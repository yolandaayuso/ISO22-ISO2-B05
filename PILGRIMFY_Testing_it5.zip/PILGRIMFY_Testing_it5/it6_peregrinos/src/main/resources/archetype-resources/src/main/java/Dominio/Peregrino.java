package Dominio;

public class Peregrino extends Usuario {

	/**
	 * 
	 * @param rese�a
	 */
	public Rese�a publicarComentario(String rese�a) {
		// TODO - implement Peregrino.publicarComentario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rese�aLike
	 */
	public void darLikeComentario(Rese�a rese�aLike) {
		// TODO - implement Peregrino.darLikeComentario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rese�aDenuncia
	 * @param motivo
	 */
	public void denunciarComentario(Rese�a rese�aDenuncia, String motivo) {
		// TODO - implement Peregrino.denunciarComentario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombreRuta
	 */
	public Ruta accederDatosRuta(String nombreRuta) {
		// TODO - implement Peregrino.accederDatosRuta
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param puntoA�adir
	 */
	public void proponerPuntoInteres(Punto_Interes puntoA�adir) {
		// TODO - implement Peregrino.proponerPuntoInteres
		throw new UnsupportedOperationException();
	}

	public Oferta[] listarOfertasRecibidas() {
		// TODO - implement Peregrino.listarOfertasRecibidas
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombreOferta
	 */
	public Oferta accederDatosOferta(String nombreOferta) {
		// TODO - implement Peregrino.accederDatosOferta
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ofertaElegida
	 * @param horaFecha
	 */
	public void generarReserva(Oferta ofertaElegida, String horaFecha) {
		// TODO - implement Peregrino.generarReserva
		throw new UnsupportedOperationException();
	}

}
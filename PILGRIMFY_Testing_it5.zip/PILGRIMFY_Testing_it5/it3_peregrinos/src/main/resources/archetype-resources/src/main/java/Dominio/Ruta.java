package Dominio;

public class Ruta {

	private String nombre;
	private int duracion;
	private double longitud;
	private Nivel_Dificultad dificultad;

}
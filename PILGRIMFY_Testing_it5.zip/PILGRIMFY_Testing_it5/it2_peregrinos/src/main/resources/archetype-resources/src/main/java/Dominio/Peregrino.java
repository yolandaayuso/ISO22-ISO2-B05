package Dominio;

public class Peregrino extends Usuario {

	/**
	 * 
	 * @param rese�a
	 */
	public Rese�a publicarComentario(String rese�a) {
		// TODO - implement Peregrino.publicarComentario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rese�aLike
	 */
	public void darLikeComentario(Rese�a rese�aLike) {
		// TODO - implement Peregrino.darLikeComentario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rese�aDenuncia
	 * @param motivo
	 */
	public void denunciarComentario(Rese�a rese�aDenuncia, String motivo) {
		// TODO - implement Peregrino.denunciarComentario
		throw new UnsupportedOperationException();
	}

}
package Presentacion;

public class IU_Peregrino {

	public void clickHacerPublicacion() {
		// TODO - implement IU_Peregrino.clickHacerPublicacion
		throw new UnsupportedOperationException();
	}

}
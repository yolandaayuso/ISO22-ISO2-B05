package Presentacion;

public class IU_ManejoApp {

	public void submmitPublicarComentario() {
		// TODO - implement IU_ManejoApp.submmitPublicarComentario
		throw new UnsupportedOperationException();
	}

	public void submmitValorarComentarios() {
		// TODO - implement IU_ManejoApp.submmitValorarComentarios
		throw new UnsupportedOperationException();
	}

}
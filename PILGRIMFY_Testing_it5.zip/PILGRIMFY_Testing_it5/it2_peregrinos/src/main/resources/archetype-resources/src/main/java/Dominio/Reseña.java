package Dominio;

public class Rese�a {

	private int id;
	private long numLikes;
	private boolean visible;

	public void sumarLike() {
		// TODO - implement Rese�a.sumarLike
		throw new UnsupportedOperationException();
	}

}
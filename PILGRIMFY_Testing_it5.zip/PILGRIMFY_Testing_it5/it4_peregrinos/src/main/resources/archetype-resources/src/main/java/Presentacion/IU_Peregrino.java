package Presentacion;

public class IU_Peregrino {

	public void clickHacerPublicacion() {
		// TODO - implement IU_Peregrino.clickHacerPublicacion
		throw new UnsupportedOperationException();
	}

	public void clickConsultarDatos() {
		// TODO - implement IU_Peregrino.clickConsultarDatos
		throw new UnsupportedOperationException();
	}

	public void clickGenerarSolicitud() {
		// TODO - implement IU_Peregrino.clickGenerarSolicitud
		throw new UnsupportedOperationException();
	}

}
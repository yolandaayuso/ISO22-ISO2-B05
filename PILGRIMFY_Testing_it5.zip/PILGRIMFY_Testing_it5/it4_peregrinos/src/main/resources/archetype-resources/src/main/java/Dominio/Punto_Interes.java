package Dominio;

public class Punto_Interes {

	private String nombre;
	private Ruta rutaAsociada;
	private String urlImagen;
	private String descripcion;

}
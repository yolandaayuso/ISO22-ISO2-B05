package Persistencia;

public class Agente {

	public void Agente() {
		// TODO - implement Agente.Agente
		throw new UnsupportedOperationException();
	}

	public Agente getAgente() {
		// TODO - implement Agente.getAgente
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SQL
	 */
	public int insert(String SQL) {
		// TODO - implement Agente.insert
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SQL
	 */
	public String[] select(String SQL) {
		// TODO - implement Agente.select
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SQL
	 */
	public int update(String SQL) {
		// TODO - implement Agente.update
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SQL
	 */
	public int delete(String SQL) {
		// TODO - implement Agente.delete
		throw new UnsupportedOperationException();
	}

}
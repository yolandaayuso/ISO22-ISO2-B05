package Presentacion;

public class IU_Usuario {

	public boolean clickIniciarSesion() {
		// TODO - implement IU_Usuario.clickIniciarSesion
		throw new UnsupportedOperationException();
	}

}
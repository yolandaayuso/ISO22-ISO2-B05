package Dominio;

public class ControlEnvioMensajes {

	/**
	 * 
	 * @param nombre
	 * @param contrase�a
	 */
	public boolean transferirCredenciales(String nombre, String contrase�a) {
		// TODO - implement ControlEnvioMensajes.transferirCredenciales
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombreUsuario
	 */
	public String solicitarContrase�aNueva(String nombreUsuario) {
		// TODO - implement ControlEnvioMensajes.solicitarContrase�aNueva
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rese�aDenuncia
	 * @param motivo
	 */
	public void enviarSolicitudDenuncia(Rese�a rese�aDenuncia, String motivo) {
		// TODO - implement ControlEnvioMensajes.enviarSolicitudDenuncia
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param puntoA�adir
	 */
	public void transmitirPropuestaPuntoInteres(Punto_Interes puntoA�adir) {
		// TODO - implement ControlEnvioMensajes.transmitirPropuestaPuntoInteres
		throw new UnsupportedOperationException();
	}

}
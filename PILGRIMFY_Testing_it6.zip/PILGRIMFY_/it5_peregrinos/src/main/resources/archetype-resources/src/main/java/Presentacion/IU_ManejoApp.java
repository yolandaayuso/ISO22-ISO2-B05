package Presentacion;

public class IU_ManejoApp {

	public void submmitPublicarComentario() {
		// TODO - implement IU_ManejoApp.submmitPublicarComentario
		throw new UnsupportedOperationException();
	}

	public void submmitValorarComentarios() {
		// TODO - implement IU_ManejoApp.submmitValorarComentarios
		throw new UnsupportedOperationException();
	}

	public void submmitVerDatosRuta() {
		// TODO - implement IU_ManejoApp.submmitVerDatosRuta
		throw new UnsupportedOperationException();
	}

	public void submmitSolicitarPuntoInteres() {
		// TODO - implement IU_ManejoApp.submmitSolicitarPuntoInteres
		throw new UnsupportedOperationException();
	}

	public void submmitVerDatosOferta() {
		// TODO - implement IU_ManejoApp.submmitVerDatosOferta
		throw new UnsupportedOperationException();
	}

	public void submmitVerListaOfertas() {
		// TODO - implement IU_ManejoApp.submmitVerListaOfertas
		throw new UnsupportedOperationException();
	}

}
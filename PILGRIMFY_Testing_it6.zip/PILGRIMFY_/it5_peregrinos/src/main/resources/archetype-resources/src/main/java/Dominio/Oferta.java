package Dominio;

public class Oferta {

	private String nombre;
	private String localAsociado;
	private String descripcion;

}
package Dominio;

public enum Nivel_Dificultad {
	Bajo,
	Medio,
	Alto
}
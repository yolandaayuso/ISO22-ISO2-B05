import static org.junit.Assert.*;

import org.junit.Test;

public class iteracion6PeregrinosTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

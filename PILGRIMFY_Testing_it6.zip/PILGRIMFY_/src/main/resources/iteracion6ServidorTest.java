import static org.junit.Assert.*;

import org.junit.Test;

public class iteracion6ServidorTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

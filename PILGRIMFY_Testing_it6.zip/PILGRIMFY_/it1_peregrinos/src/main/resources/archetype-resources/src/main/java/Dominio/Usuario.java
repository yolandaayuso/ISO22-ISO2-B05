package Dominio;

public class Usuario {

	private String nombre;
	private String contrase�a;
	private String correoElectronico;

	/**
	 * 
	 * @param nombre
	 * @param contrase�a
	 */
	public boolean iniciarSesion(String nombre, String contrase�a) {
		// TODO - implement Usuario.iniciarSesion
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombre
	 */
	public String recuperarContrase�a(String nombre) {
		// TODO - implement Usuario.recuperarContrase�a
		throw new UnsupportedOperationException();
	}

}
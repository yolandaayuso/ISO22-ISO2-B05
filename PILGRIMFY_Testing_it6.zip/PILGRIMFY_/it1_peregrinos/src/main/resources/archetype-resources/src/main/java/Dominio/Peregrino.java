package Dominio;

public class Peregrino extends Usuario {
}